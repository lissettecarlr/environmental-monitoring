package com.allen.model;

public class user {

}
