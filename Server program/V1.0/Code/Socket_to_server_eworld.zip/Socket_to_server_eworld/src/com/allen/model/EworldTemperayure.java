package com.allen.model;

public class EworldTemperayure extends Eworld{
	private float eData;
	private String DeviceName= "�¶ȴ�����";
	
	
	public String getDeviceName() {
		return DeviceName;
	}
	public float geteData() {
		return eData;
	}

	public void seteData(float eData) {
		this.eData = eData;
	}
}
