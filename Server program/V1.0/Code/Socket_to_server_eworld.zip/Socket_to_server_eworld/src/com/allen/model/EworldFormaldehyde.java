package com.allen.model;

public class EworldFormaldehyde extends Eworld{
	private float eData;
	private String DeviceName= "��ȩ������";
	
	
	public String getDeviceName() {
		return DeviceName;
	}
	public float geteData() {
		return eData;
	}

	public void seteData(float eData) {
		this.eData = eData;
	}
}
