package com.allen.model;

public class EworldDust extends Eworld{
	private float eData;
	private String DeviceName= "�۳���PM2.5��������";
	
	
	public String getDeviceName() {
		return DeviceName;
	}
	public float geteData() {
		return eData;
	}

	public void seteData(float eData) {
		this.eData = eData;
	}
}
