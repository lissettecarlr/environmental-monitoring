package com.allen.model;

public class EworldHumidity extends Eworld{
	private float eData;
	private String DeviceName= "ʪ�ȴ�����";
	
	
	public String getDeviceName() {
		return DeviceName;
	}
	public float geteData() {
		return eData;
	}

	public void seteData(float eData) {
		this.eData = eData;
	}
}
